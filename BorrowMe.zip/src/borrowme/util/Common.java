package borrowme.util;

public interface Common {
	String CLOTHES			= "00";
	String SHIRTS			= "01";
	String TSHIRTS			= "02";
	String MANTOMAN			= "03";
	String KNIT				= "04";
	String ONEPIECE			= "05";
	String OUTER			= "06";
	String PANTS			= "07";
	String SKIRT			= "08";
	String ACC				= "09";
	
	
	String KIDS					= "10";
	String BUGGY				= "11";
	String TOY					= "12";
	String GAME					= "13";
	String CHILD				= "14";
	String FUNITURE				= "15";
	
	String IT					= "20";
	String NOTEBOOK				= "21";
	String CAMERA				= "22";
	String PHONE				= "23";
	String TABLET				= "24";
	String ITETC				= "25";
	
	String SPORTS				= "30";
	String MOBILITY				= "31";
	String HEALTH				= "32";
	String SKI					= "33";
	
	String HOBBY				= "40";
	String FISHING				= "41";
	String INSTRUMENT			= "42";
	String CAMPING				= "43";
	
	//
	String CHARGE        = "01";
	String USAGE         = "02";

	// Main
	int MAIN_LIST_NUM    = 8;
	
}
