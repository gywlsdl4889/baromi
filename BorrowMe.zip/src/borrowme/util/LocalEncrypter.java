package borrowme.util;

import java.io.IOException;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class LocalEncrypter {
  private static LocalEncrypter instance = new LocalEncrypter();
  
  public static LocalEncrypter getInstance() {
    return instance;
  }
  
  public String encorder(String str){
    BASE64Encoder encorder = new BASE64Encoder();
    String encode = encorder.encode(str.getBytes());
    return encode;
  }
  
  public String decorder(String encode){
    byte[] decode = null;
    BASE64Decoder decoder = new BASE64Decoder();
    
    try {
      decode = decoder.decodeBuffer(encode);
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    
    return new String(decode);
  }

}
