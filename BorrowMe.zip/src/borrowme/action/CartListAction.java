package borrowme.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import borrowme.dao.ProductDaoImpl;
import borrowme.dto.ProductDto;

public class CartListAction implements Action {

  @Override
  public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
	HttpSession session = request.getSession();
	List<ProductDto> list = null;
	
	String num = request.getParameter("num");
	System.out.println("num=" + num);
	
	list = (List<ProductDto>) session.getAttribute("cart");
	
	list.remove(Integer.parseInt(num));
	
	System.out.println(list.size());
	
	//session.removeAttribute("cart");
	if(list!=null){
		session.setAttribute("cart", list);
	}
	
    ActionForward forward = new ActionForward();
    forward.setNextURL("product?cmd=cartFormList");
    forward.setForward(false);
    
    
    return forward;
  }

}
