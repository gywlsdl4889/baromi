package borrowme.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import borrowme.dao.ProductDaoImpl;
import borrowme.dto.BorrowDto;
import borrowme.dto.ThumbNailDto;

public class BorrowListAction implements Action {

  @Override
  public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub
	  
	String memMail = request.getParameter("memMail");
	
    List<BorrowDto> list = ProductDaoImpl.getInstance().borrowList(memMail);
//    List<ThumbNailDto> listT = ProductDaoImpl.getInstance().ThumbList(proNum);
    
    ActionForward forward = new ActionForward();
    
    if(list!=null){
      request.setAttribute("borrowList", list);
      forward.setNextURL("./borrow_list.jsp");
      forward.setForward(true);
    } else {
      
    }
    
    return forward;
  }
  /*  ActionForward forward = new ActionForward();
    forward.setForward(true);
    forward.setNextURL("./borrow_list.jsp");
    return forward;*/
  }
