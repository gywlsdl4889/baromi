package borrowme.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import borrowme.dao.ProductDaoImpl;
import borrowme.dto.CartDto;
import borrowme.dto.MainListDto;
import borrowme.dto.ProductDto;


public class CartAddAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		List<CartDto> list = null;

		String proNum = request.getParameter("proNum");
		System.out.println("pronum : " + proNum);
		
		
		CartDto cartList = ProductDaoImpl.getInstance().cartList(proNum);
		
		list = (List<CartDto>) session.getAttribute("cart");
			
			
		if(list == null)
			list = new ArrayList<CartDto>();
		
		list.add(cartList);
		
		session.setAttribute("cart", list);
		
		
		if(list!=null){
			System.out.println("ggg"+list.size());
		}
		
		ActionForward forward = new ActionForward();
		
		forward.setNextURL("product?cmd=cartListForm");
		forward.setForward(false);
		
		return forward;
	}

}
