package borrowme.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import borrowme.dao.MemberDaoImpl;
import borrowme.util.LocalEncrypter;

public class CheckPwAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		String memMail = request.getParameter("memMail");
		String memPw = LocalEncrypter.getInstance().encorder(request.getParameter("memPw"));

		System.out.println(memPw);

		boolean check = MemberDaoImpl.getInstance().checkPw(memMail, memPw);
		System.out.println(check);
		PrintWriter out = response.getWriter();
		out.print(check);
		out.close();

		return null;
	}

}
