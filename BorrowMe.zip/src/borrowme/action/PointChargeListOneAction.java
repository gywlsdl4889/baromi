package borrowme.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import borrowme.dao.PointDaoImpl;
import borrowme.dto.MemberDto;

public class PointChargeListOneAction implements Action {

  @Override
  public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub
    
    String memMail = request.getParameter("memMail");
    
    MemberDto m = PointDaoImpl.getInstance().selectOneByCharage(memMail);
    
    ActionForward forward = new ActionForward();
    
    request.setAttribute("userPoint", m);
    forward.setForward(true);
    forward.setNextURL("./point_charge.jsp");
    
    return forward;
  }

}
