package borrowme.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import borrowme.dao.MemberDaoImpl;
import borrowme.dto.MemberDto;
import borrowme.util.LocalEncrypter;

public class LoginAction implements Action {

  @Override
  public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub
    
    Logger logger = Logger.getLogger("LoginAction.class");
    
    logger.info("---------------Login Action---------------");
    
    String memMail = request.getParameter("memMail");
    String memPw = LocalEncrypter.getInstance().encorder(request.getParameter("memPw"));
    
    MemberDto m = null;
    
    m = MemberDaoImpl.getInstance().login(memMail, memPw);
    
    ActionForward forward = new ActionForward();
    String loginfail = null;
    if(m!=null){
      HttpSession session=request.getSession();
      session.setAttribute("loginInfo", m);
      forward.setNextURL("./index.jsp");
      forward.setForward(true);
    } else {
      forward.setNextURL("./login.jsp");
      forward.setForward(true);
      loginfail = "�α��ν���";
      request.setAttribute("loginfail", loginfail);
    }
    
    return forward;
  }

}
