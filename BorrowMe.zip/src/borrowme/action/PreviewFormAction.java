package borrowme.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import borrowme.dao.ProductDaoImpl;
import borrowme.dto.ProductDto;
import borrowme.dao.OfficeDaoImpl;
import borrowme.dto.OfficeDto;
import borrowme.dao.BorrowDaoImpl;
import borrowme.dto.BorrowDto;

public class PreviewFormAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//��ǰ
		String proNum = request.getParameter("proNum");
		//��ǰ�� �ִ� ������

		ActionForward forward = new ActionForward();
		ProductDto p = null;
		OfficeDto o = null;
		List<OfficeDto> off = null;
		BorrowDto b = null;
		
		// ��ǰ��ȣ/��ǰ��/��ǰ�󼼳���/��ǰ����Ͻ�/��ǰ����/�뿩����/�뿩���ɿ���/��ȸ��/������/ȸ���̸���
		// proNum proName proDetail proDate proSort proCost proAvail proCount proRate memMail
		//offNum offName offHp offAddr

		p = ProductDaoImpl.getInstance().selectOneByProNum(proNum);
		o = OfficeDaoImpl.getInstance().selectOffNameByProNum(proNum);
		off = OfficeDaoImpl.getInstance().selectAllOfficeList();
		b = BorrowDaoImpl.getInstance().selectOrdEndByProNum(proNum);
		
		System.out.println(p.getProNum());
		System.out.println(p.getProName());
		System.out.println(p.getProDetail());
		System.out.println(p.getProDate());
		
		System.out.println(o.getOffName());
		
		
		if (p != null & o != null & off != null) {
			request.setAttribute("ProductDto", p);
			request.setAttribute("OfficeDto", o);
			request.setAttribute("officeList", off);
			forward.setNextURL("./preview.jsp");
			forward.setForward(true);
		}
		if (b != null){
			request.setAttribute("BorrowDto", b);
			forward.setNextURL("./preview.jsp");
			forward.setForward(true);
		}else if(b == null){
			request.setAttribute("BorrowDto", b);
			forward.setNextURL("./preview.jsp");
			forward.setForward(true);
		}
		/*if(o != null){
			request.setAttribute("OfficeDto", o);
			forward.setNextURL("./preview.jsp");
			forward.setForward(true);
		}
		if(off != null){
			request.setAttribute("officeList", off);
			forward.setNextURL("./preview.jsp");
			forward.setForward(true);
		}*/

		return forward;

	}

}
