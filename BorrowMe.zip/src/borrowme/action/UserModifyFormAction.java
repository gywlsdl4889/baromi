package borrowme.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import borrowme.dao.MemberDaoImpl;
import borrowme.dto.MemberDto;

public class UserModifyFormAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// TODO Auto-generated method stub
		
		String memMail = request.getParameter("memMail");

		ActionForward forward = new ActionForward();
		MemberDto m = null;
		// memMail, memPw, memName, memAddr, memHp, memGen, memBirth
		m = MemberDaoImpl.getInstance().selectOneByMember(memMail);
		//System.out.println(m);
		if (m != null) {
			request.setAttribute("MemberDto", m);
			forward.setNextURL("./user_modify.jsp");
			//forward.setNextURL("./index.jsp");
			forward.setForward(true);
		} else {

		}

		return forward;
	}

}
