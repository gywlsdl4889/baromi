package borrowme.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import borrowme.dao.ProductDaoImpl;
import borrowme.dto.LocDto;


public class LocFindAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String proNum = request.getParameter("proNum");
		
		List<LocDto> list = ProductDaoImpl.getInstance().locFind(proNum);
		
		ActionForward forward = new ActionForward();
		if (list != null) {
			request.setAttribute("locList", list);
			forward.setForward(true);
			forward.setNextURL("./loc.jsp");
		}
		else{
			
		}
		return forward;
	}

}
