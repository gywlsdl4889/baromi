package borrowme.action;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import borrowme.dao.MemberDaoImpl;
import borrowme.dto.MemberDto;
import borrowme.util.LocalEncrypter;

public class RegisterAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		String memMail = request.getParameter("memMail");
		String memPw = LocalEncrypter.getInstance().encorder(request.getParameter("memPw"));
		String memName = request.getParameter("memName");
		String memAddr = request.getParameter("memAddr");
		String memHp = request.getParameter("memHp");
		String memGen = request.getParameter("memGen");
		String memBirth = request.getParameter("memBirth");

		/*MemberDto mdto = new MemberDto();

		mdto.setMemMail(memMail);
		mdto.setMemPw(memPw);
		mdto.setMemName(memName);
		mdto.setMemBirth(memBirth);
		mdto.setMemGen(memGen);
		mdto.setMemHp(memHp);
		mdto.setMemAddr(memAddr);
		
		int result = MemberDaoImpl.getInstance().insertRegister(m);
	    
	    ActionForward forward = new ActionForward();
	    
	    if(result != 0) {
	      forward.setNextURL("/loginForm.six");
	      forward.setForward(true);
	    } else {
	      request.setAttribute("errorMsg", "ȸ�����Խ���");
	      forward.setNextURL("./error/error.jsp");
	      forward.setForward(true);
	    }

	    return forward;*/
		

		ActionForward forward = new ActionForward();
		Boolean result = false;

		result = MemberDaoImpl.getInstance()
				.insertRegister(new MemberDto(memMail, memPw, memName, memAddr, memHp, memGen, memBirth));
		System.out.println(result);
		if (result) {
			forward.setNextURL("member?cmd=loginForm");
			forward.setForward(false);
		} else {

		}

		return forward;
	}

}
