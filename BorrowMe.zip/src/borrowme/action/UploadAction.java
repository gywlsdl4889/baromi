package borrowme.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import borrowme.dao.ProductDaoImpl;
import borrowme.dto.ItemImgDto;
import borrowme.dto.LocationDto;
import borrowme.dto.ProductDto;

public class UploadAction implements Action {
	public ActionForward execute(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Writeaction");
		Logger logger = Logger.getLogger("UploadAction.class");
		String saveDir= request.getServletContext().getRealPath("/upload"); //C:\fileUpload
		
	    
	    logger.info("file url : " + saveDir);
		
		System.out.println(saveDir);
		System.out.println("Writeaction1");
		int maxSize=1024*1024*100;//100m
		String encoding="UTF-8";
		System.out.println("Writeaction2");
		MultipartRequest m =
				  new MultipartRequest(request, saveDir,maxSize, encoding, new DefaultFileRenamePolicy());
		
		String local = m.getParameter("local");
		
		
		String proSort = m.getParameter("proSort");
		String detailSort = m.getParameter("detailSort");
		String proName = m.getParameter("proName");
		String proDetail = m.getParameter("proDetail");
		int proCost = Integer.parseInt(m.getParameter("proCost"));
		String memMail = m.getParameter("memMail");
		
		String[] img = {m.getFilesystemName("img1"), m.getFilesystemName("img2"),m.getFilesystemName("img3"),m.getFilesystemName("img4"), m.getFilesystemName("img5")}; 
		
		ProductDto product = new ProductDto();
		
		product.setProName(proName);
		product.setProDetail(proDetail);
		product.setProSort(proSort);
		product.setProCost(proCost);
		product.setMemMail(memMail);
		
		boolean result = false;
		
		if(proSort.equals("�Ƿ�")){
			product.setCloSort(detailSort);
			result = ProductDaoImpl.getInstance().insertProductClosort(product);
		}else if(proSort.equals("���ڱ��")){
			product.setItSort(detailSort);
			result = ProductDaoImpl.getInstance().insertProductItSort(product);
		}else if(proSort.equals("�Ƶ���ǰ")){
			product.setKidSort(detailSort);
			result = ProductDaoImpl.getInstance().insertProductKidsort(product);
		}else if(proSort.equals("������")){
			product.setSpoSort(detailSort);
			result = ProductDaoImpl.getInstance().insertProductSposort(product);
		}else if(proSort.equals("���")){
			product.setHobSort(detailSort);
			result = ProductDaoImpl.getInstance().insertProductHobsort(product);
		}
		
		String num = ProductDaoImpl.getInstance().selectProductNum(memMail);
		
		
		
		LocationDto location = new LocationDto();
		location.setProNum(num);
		location.setOffNum(local);
		
		boolean result1 = ProductDaoImpl.getInstance().insertLocation(location);
		
		ItemImgDto itemImg = new ItemImgDto();
		itemImg.setProNum(num);
		for(int i=0; i<img.length; i++){
			if(img[i] != null) {
				itemImg.setIteIdx(Integer.toString(i+1));
				itemImg.setIteFile(img[i]);
				ProductDaoImpl.getInstance().insertItemImg(itemImg);
			} else {
				break;
			}
		}
		
		 

		ActionForward forward = new ActionForward();
		
		if(result && result1 ){
			forward.setForward(false);
			forward.setNextURL("#");
		}else{
			
		}

		return forward;
	}
}