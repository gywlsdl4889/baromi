package borrowme.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import borrowme.dao.MemberDaoImpl;
import borrowme.dto.MemberDto;
import borrowme.util.LocalEncrypter;

public class ResetPwdAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String memMail =request.getParameter("memMail");		
		String newpwd1 = request.getParameter("newpwd1");
		String memPwd = LocalEncrypter.getInstance().encorder(request.getParameter("newpwd1"));
		String newpwd2 = request.getParameter("newpwd2");
		
		MemberDto m = null;
		
		ActionForward forward = new ActionForward();
				
		String resetMessage = null;
		
		if(newpwd1.equals(newpwd2)){
			m = MemberDaoImpl.getInstance().resetPw(memMail, memPwd);	
			resetMessage = "resetok";
			request.setAttribute("resetMessage", resetMessage);
			forward.setNextURL("./login.jsp");
			forward.setForward(true);
		}else{
			resetMessage = "resetfail";
			request.setAttribute("resetMessage", resetMessage);
			forward.setNextURL("./reset_pwd.jsp");
			forward.setForward(true);
		}
		
		return forward;
	}

}
