package borrowme.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import borrowme.dao.MemberDaoImpl;
import borrowme.dto.MemberDto;
import borrowme.util.LocalEncrypter;

public class UserModifyAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// TODO Auto-generated method stub

		String memMail = request.getParameter("memMail");
		String memPw2 = LocalEncrypter.getInstance().encorder(request.getParameter("memPw2"));
		String memHp2 = request.getParameter("memHp2");
		String memAddr2 = request.getParameter("memAddr2");
		
		/*System.out.println(memMail);
		System.out.println(memPw);
		System.out.println(memHp);
		System.out.println(memAddr);*/
		
		ActionForward forward = new ActionForward();
		Boolean result = false;
		// memMail, memPw, memName, memAddr, memHp, memGen, memBirth result =
		
		MemberDto m = new MemberDto();
		m.setMemMail(memMail);
		m.setMemPw(memPw2);
		m.setMemHp(memHp2);
		m.setMemAddr(memAddr2);
		
		/*System.out.println(m.getMemMail());
		System.out.println(m.getMemPw());
		System.out.println(m.getMemHp());
		System.out.println(m.getMemAddr());*/
		
		result = MemberDaoImpl.getInstance().updateMember(m);
		
		if (result) {
			HttpSession session=request.getSession();
		    session.invalidate(); // ��� ���������� �����ϰ�
		    
			forward.setNextURL("./index.jsp");
			forward.setForward(false);
		} else {

		}

		return forward;

	}

}
