package borrowme.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import borrowme.dao.ProductDaoImpl;
import borrowme.dto.ProductDto;

public class LendListAction implements Action {

  @Override
  public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub
    
    String memMail = request.getParameter("memMail");
    
    List<ProductDto> list = ProductDaoImpl.getInstance().selectAllLendList(memMail);
    
    ActionForward forward = new ActionForward();
    
    if(list!=null){
      request.setAttribute("lendList", list);
      forward.setNextURL("./lend_list.jsp");
      forward.setForward(true);
    } else {
      
    }
    
    return forward;
  }

}
