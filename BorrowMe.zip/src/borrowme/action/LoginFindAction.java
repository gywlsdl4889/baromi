package borrowme.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import borrowme.dao.MemberDaoImpl;
import borrowme.dto.MemberDto;

public class LoginFindAction implements Action {

  @Override
  public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {

    String menu = (String)request.getParameter("menu");
    request.setAttribute("menu", menu);
    
    String memMail = request.getParameter("memMail");
    String memName = request.getParameter("memName");
    String memBirth = request.getParameter("memBirth");

    MemberDto m = null;
    System.out.println("LoginFindAction"+memMail);

    ActionForward forward = new ActionForward();

    String check = null;
    
    if(menu.equals("mail")){
	    m = MemberDaoImpl.getInstance().findMail(memName, memBirth);
	    if (m != null) {
	        request.setAttribute("Emailinfo", m);
	        forward.setNextURL("./message.jsp"); // ã�Ҵٴ°� �����ִ� view�����
	        System.out.println("1");
	      } else {
	    	check = "Ʋ������";
	    	request.setAttribute("check", check);
	        forward.setNextURL("./login_find.jsp"); // Ʋ�ȴٰ� �ٽ��϶�� dialog����ֱ� alertâ
	        System.out.println("2");
	      }
        forward.setForward(true);
    }else if(menu.equals("pw")){
	    m = MemberDaoImpl.getInstance().findPw(memMail, memName, memBirth);  
	    if (m != null) {
	    	request.setAttribute("memMail", memMail);
	    	forward.setNextURL("./reset_pwd.jsp"); // ��й�ȣ �缳��â���� ����
	        System.out.println("3");
	      } else {
	    	check = "Ʋ������";
	    	request.setAttribute("check", check);
	    	request.setAttribute("memMail", memMail);
	        forward.setNextURL("./login_find.jsp"); // Ʋ�ȴٰ� �ٽ��϶�� dialog����ֱ� alertâ
	        m.setMemMail(memMail);
	      }
	    forward.setForward(true);
    }
    


    return forward;
  }

}
