package borrowme.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import borrowme.dao.MemberDaoImpl;
import borrowme.dto.MemberDto;

public class DeleteAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		String memMail = request.getParameter("memMail");

		boolean result = MemberDaoImpl.getInstance().deleteMember(memMail);

		ActionForward forward = new ActionForward();

		if (result) {
			HttpSession session = request.getSession();
			session.invalidate(); // ��� ���������� �����ϰ�
			forward.setNextURL("./index.jsp");
			forward.setForward(true);
		} else {
			// �ش� ID�� �����ϴ�.
		}

		return forward;
	}

}
