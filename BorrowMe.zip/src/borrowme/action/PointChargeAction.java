package borrowme.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import borrowme.dao.PointDaoImpl;
import borrowme.dto.PointDto;
import borrowme.util.Common;

public class PointChargeAction implements Action {

  @Override
  public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub
    String memMail = request.getParameter("memMail");
    int cash = Integer.parseInt(request.getParameter("cash"));
    
    PointDto point = new PointDto();
    point.setMemMail(memMail);
    point.setPoiPoint(cash);
    point.setPoiSort(Common.CHARGE);
    
    // Point ���̺� insert
    boolean result = PointDaoImpl.getInstance().insertPoint(point);
    // Member ���̺��� memPoint ��������
    int totalPoint = PointDaoImpl.getInstance().selectTotalPoint(memMail);
    // Member ���̺��� memPoint update
    totalPoint += cash;
    point.setPoiPoint(totalPoint);
    boolean result1 = PointDaoImpl.getInstance().updateTotalPoint(point);
    
    ActionForward forward = new ActionForward();
    
    if(result && result1){
      forward.setForward(true);
      forward.setNextURL("point?cmd=pointChargeListOne&memMail=" + point.getMemMail());
    } else {
      
    }
    
    return forward;
  }

}
