package borrowme.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;

import borrowme.dao.ProductDaoImpl;
import borrowme.dto.ProductDto;
import borrowme.util.Common;

public class ProductMainListAction implements Action {

  @Override
  public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub

    List<ProductDto> list = ProductDaoImpl.getInstance().selectProductMainList(Common.MAIN_LIST_NUM);
    
    PrintWriter out = response.getWriter();
    JSONArray obj = new JSONArray(list);
    System.out.println(obj);
    out.print(obj.toString());
    
    return null;
  }

}
