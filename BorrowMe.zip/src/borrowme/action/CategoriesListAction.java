package borrowme.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import borrowme.dao.ProductDaoImpl;
import borrowme.dto.ProductDto;

public class CategoriesListAction implements Action {

  @Override
  public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub
	String menu = request.getParameter("menu");
	String sortOption = request.getParameter("sortOption");
	
	
	request.setAttribute("menu", menu);
	
	
	System.out.println(menu + "=" + sortOption);  
	
	
	//List<ProductDto> list = ProductDaoImpl.getInstance().categoryOneByMenu(menu);
	List<ProductDto> listOption = ProductDaoImpl.getInstance().categoryByOption(menu, sortOption);
	
	
	
	
	ActionForward forward = new ActionForward();
    
    if(listOption!=null){
    	//request.setAttribute("categoriesList", list);
    	request.setAttribute("categoriesListOption", listOption);
    	/*request.setAttribute("listOptionSize", listOption.size());*/
    	request.setAttribute("sortOptionCopy", sortOption);
    	forward.setNextURL("./categories_list.jsp");
    	forward.setForward(true);
    }else{
    	
    }
    
    return forward;
  }
  
}
