package borrowme.dao;

import borrowme.dto.MemberDto;
import borrowme.dto.PointDto;

public interface PointDao {
  MemberDto selectOneByCharage(String memMail);
  boolean insertPoint(PointDto point);
  boolean updateTotalPoint(PointDto point);
  int selectTotalPoint(String memMail);
  
}
