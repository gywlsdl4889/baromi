package borrowme.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import borrowme.dto.OfficeDto;
import borrowme.util.DBManager;

public class OfficeDaoImpl implements OfficeDao {

	private static OfficeDaoImpl instance = new OfficeDaoImpl();

	public static OfficeDaoImpl getInstance() {
		return instance;
	}

	private OfficeDaoImpl() {
	}

	@Override
	public OfficeDto selectOffNameByProNum(String proNum) {
		SqlSession session = null;
		OfficeDto o = null;
		
		try {
			session = DBManager.getSqlSession();
			o = session.selectOne("borrowme.mapper.selectOffNameByProNum", proNum);
		} finally {
			DBManager.closeSqlSession(session);
		}

		return o;
	}

	@Override
	public List<OfficeDto> selectAllOfficeList() {
		// TODO Auto-generated method stub
		SqlSession session = null;
		//List<OfficeDto> list = null;
		List<OfficeDto> list = new ArrayList<OfficeDto>();

		try {
			session = DBManager.getSqlSession();
			list = session.selectList("borrowme.mapper.selectAllOfficeList");
		} finally {
			DBManager.closeSqlSession(session);
		}

		return list;
	}	
	

}
