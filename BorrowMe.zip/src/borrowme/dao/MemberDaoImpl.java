package borrowme.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import borrowme.dto.MemberDto;
import borrowme.util.DBManager;

public class MemberDaoImpl implements MemberDao {

	private static MemberDaoImpl instance = new MemberDaoImpl();

	public static MemberDaoImpl getInstance() {
		return instance;
	}

	private MemberDaoImpl() {
	}

	@Override
	public boolean insertRegister(MemberDto m) {
		// TODO Auto-generated method stub
		SqlSession session = null;
		boolean result = false;

		try {
			session = DBManager.getSqlSession();
			result = session.insert("borrowme.mapper.insertRegister", m) > 0 ? true : false;
		} finally {
			DBManager.closeSqlSession(result, session);
		}

		return result;
	}

	@Override
	public List<MemberDto> selectAllMembers(String memMail) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MemberDto selectOneByMember(String memMail) {
		SqlSession session = null;
		MemberDto m = null;
	    
	    try{
	    	session = DBManager.getSqlSession();
	    	m = session.selectOne("borrowme.mapper.userDetail", memMail);
	    }finally {
	    	DBManager.closeSqlSession(session);
	    }
	    
	    return m;
	}

	// ȸ�� ���̵� �ߺ� üũ
	public boolean checkMail(String memMail) {
		SqlSession session = null;
		boolean result = false;

		HashMap<String, String> map = new HashMap<String, String>();

		map.put("memMail", memMail);

		try {
			session = DBManager.getSqlSession();
			result = session.selectOne("borrowme.mapper.checkMail", map) != null ? true: false;
		} finally {
			DBManager.closeSqlSession(session);
		}

		return result;
	}

	@Override
	public boolean checkPw(String memMail, String memPw) {
		SqlSession session = null;
		boolean result = false;
		
		HashMap<String, String> map = new HashMap<String, String>();

		map.put("memMail", memMail);
		map.put("memPw", memPw);

		try {
			session = DBManager.getSqlSession();
			result = session.selectOne("borrowme.mapper.checkPw", map) != null ? true: false;
		} finally {
			DBManager.closeSqlSession(session);
		}

		return result;
	}
	
	@Override
	public MemberDto login(String memMail, String memPw) {
		// TODO Auto-generated method stub
		SqlSession session = null;
		MemberDto m = null;
		HashMap<String, String> map = new HashMap<String, String>();

		map.put("memMail", memMail);
		map.put("memPw", memPw);

		try {
			session = DBManager.getSqlSession();
			m = session.selectOne("borrowme.mapper.login", map);
		} finally {
			DBManager.closeSqlSession(session);
		}

		return m;
	}

	@Override
	public boolean updateMember(MemberDto m) {
		SqlSession session = null;
		boolean result = false;
		/*System.out.println(m.getMemMail());
		System.out.println(m.getMemPw());
		System.out.println(m.getMemHp());
		System.out.println(m.getMemAddr());*/
		
		try {
			session = DBManager.getSqlSession();
			result = session.update("borrowme.mapper.userModify", m) > 0 ? true : false;
		} finally {
			DBManager.closeSqlSession(result, session);
		}
		
		return result;
	}

	@Override
	public boolean deleteMember(String memMail) {
		// TODO Auto-generated method stub
		SqlSession session = null;
		boolean result = false;
		try {
			session = DBManager.getSqlSession();
			result = session.delete("borrowme.mapper.deleteMember", memMail) > 0 ? true : false;
		} finally {
			DBManager.closeSqlSession(result, session);
		}
		
		return result;
	}

	@Override
	public MemberDto findMail(String memName, String memBirth) {
		// TODO Auto-generated method stub
	  SqlSession session = null;
    MemberDto m = null;
    HashMap<String, String> map = new HashMap<String, String>();
    
    map.put("memName", memName);
    map.put("memBirth", memBirth);
   
    
    try{
      session = DBManager.getSqlSession();
      m = session.selectOne("borrowme.mapper.login_find_id", map);
    }catch(Exception e){
      e.printStackTrace();
    } 
    
    return m;
	}

	@Override
	public MemberDto findPw(String memMail, String memName, String memBirth) {
		// TODO Auto-generated method stub
	  SqlSession session = null;
    MemberDto m = null;
    HashMap<String, String> map = new HashMap<String, String>();
    
    map.put("memMail", memMail);
    map.put("memName", memName);
    map.put("memBirth", memBirth);
    
    try{
      session = DBManager.getSqlSession();
      m = session.selectOne("borrowme.mapper.login_find_pw", map);
    } catch(Exception e){
      e.printStackTrace();
    } 
    
    return m;
	}

	public MemberDto resetPw(String memMail, String memPwd) {
		// TODO Auto-generated method stub
		SqlSession session = null;
	    MemberDto m = null;
	    boolean result = false;
	    HashMap<String, String> map = new HashMap<String, String>();
	    
	    map.put("memMail", memMail);
	    map.put("memPwd", memPwd);
	    
	    try{
	    	session = DBManager.getSqlSession();   
	    	result = session.update("borrowme.mapper.reset_pwd", map) > 0 ? true : false;
	    } catch(Exception e){
	      e.printStackTrace();
	    } finally{
	    	DBManager.closeSqlSession(result, session);
	    }
	    
	    return m;
	}
	
	
}
