package borrowme.dao;

import java.util.List;

import borrowme.dto.BorrowDto;

public interface BorrowDao {
	BorrowDto selectOrdEndByProNum(String proNum); //
}
