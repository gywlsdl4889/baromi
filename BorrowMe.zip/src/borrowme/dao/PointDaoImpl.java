package borrowme.dao;

import org.apache.ibatis.session.SqlSession;

import borrowme.dto.MemberDto;
import borrowme.dto.PointDto;
import borrowme.util.DBManager;

public class PointDaoImpl implements PointDao {

  private static PointDaoImpl instance = new PointDaoImpl();

  public static PointDaoImpl getInstance() {
    return instance;
  }

  private PointDaoImpl() {
  }
  
  @Override
  public MemberDto selectOneByCharage(String memMail) {
    // TODO Auto-generated method stub
    SqlSession session = null;
    MemberDto m = null;

    try {
      session = DBManager.getSqlSession();
      m = session.selectOne("borrowme.mapper.selectOneByCharage", memMail);
    } finally {
      DBManager.closeSqlSession(session);
    }

    return m;
  }

  @Override
  public boolean insertPoint(PointDto point) {
    // TODO Auto-generated method stub
    SqlSession session = null;
    boolean result = false;
    
    try {
      session = DBManager.getSqlSession();
      result = session.insert("borrowme.mapper.insertPoint", point) > 0 ? true : false ;
    } finally {
      DBManager.closeSqlSession(result, session);
    }

    return result;
  }

  @Override
  public boolean updateTotalPoint(PointDto point) {
    // TODO Auto-generated method stub
    SqlSession session = null;
    boolean result = false;
    
    try {
      session = DBManager.getSqlSession();
      result = session.insert("borrowme.mapper.updateTotalPoint", point) > 0 ? true : false ;
    } finally {
      DBManager.closeSqlSession(result, session);
    }

    return result;
  }

  @Override
  public int selectTotalPoint(String memMail) {
    // TODO Auto-generated method stub
    SqlSession session = null;
    int value = 0;
    
    try {
      session = DBManager.getSqlSession();
      value = session.selectOne("borrowme.mapper.selectTotalPoint", memMail);
    } finally {
      DBManager.closeSqlSession(session);
    }
    
    return value;
  }

}
