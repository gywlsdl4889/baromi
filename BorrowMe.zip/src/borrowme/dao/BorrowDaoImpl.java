package borrowme.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import borrowme.dto.BorrowDto;
import borrowme.util.DBManager;

public class BorrowDaoImpl implements BorrowDao {

	private static BorrowDaoImpl instance = new BorrowDaoImpl();

	public static BorrowDaoImpl getInstance() {
		return instance;
	}

	private BorrowDaoImpl() {
	}
	
	@Override
	public BorrowDto selectOrdEndByProNum(String proNum) {
		SqlSession session = null;
		BorrowDto b = null;

		try {
			session = DBManager.getSqlSession();
			b = session.selectOne("borrowme.mapper.selectOrdEndByProNum", proNum);
		} finally {
			DBManager.closeSqlSession(session);
		}

		return b;
	}
  
}
