package borrowme.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import borrowme.dto.BorrowDto;
import borrowme.dto.CartDto;
import borrowme.dto.ItemImgDto;
import borrowme.dto.LendDto;
import borrowme.dto.LocDto;
import borrowme.dto.LocationDto;
import borrowme.dto.MainListDto;
import borrowme.dto.ProductDto;
import borrowme.dto.ThumbNailDto;
import borrowme.util.DBManager;

public class ProductDaoImpl implements ProductDao {

  private static ProductDaoImpl instance = new ProductDaoImpl();

  public static ProductDaoImpl getInstance() {
    return instance;
  }

  private ProductDaoImpl() {
  }

  @Override
  public List<ProductDto> selectAllProduct(int page) {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
	public ProductDto selectOneByProNum(String proNum) {
		SqlSession session = null;
		ProductDto p = null;

		try {
			session = DBManager.getSqlSession();
			p = session.selectOne("borrowme.mapper.selectOneByProNum", proNum);
		} finally {
			DBManager.closeSqlSession(session);
		}

		return p;
	}

  @Override
  public void updateReadCount(int num) {
    // TODO Auto-generated method stub

  }

  @Override
  public boolean updateBoard(ProductDto Member) {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public boolean deleteBoard(int num) {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public List<ProductDto> selectAllLendList(String memMail) {
    // TODO Auto-generated method stub
    SqlSession session = null;
    List<ProductDto> list = null;

    try {
      session = DBManager.getSqlSession();
      list = session.selectList("borrowme.mapper.selectAllLendList", memMail);
    } finally {
      DBManager.closeSqlSession(session);
    }

    return list;
  }

  @Override
  public boolean insertLocation(LocationDto location) {
    // TODO Auto-generated method stub
    SqlSession session = null;
    boolean result = false;

    try {
      session = DBManager.getSqlSession();
      result = session.insert("borrowme.mapper.insertLocation", location) > 0 ? true : false;
    } finally {
      DBManager.closeSqlSession(result, session);
    }

    return result;
  }

  @Override
  public boolean insertProductClosort(ProductDto product) {
    // TODO Auto-generated method stub
    SqlSession session = null;
    boolean result = false;

    try {
      session = DBManager.getSqlSession();
      result = session.insert("borrowme.mapper.insertProductClosort", product) > 0 ? true : false;
    } finally {
      DBManager.closeSqlSession(result, session);
    }
    return result;
  }

  public List<LocDto> locFind(String proNum) {
    SqlSession session = null;
    List<LocDto> list = null;

    try {
      session = DBManager.getSqlSession();
      list = session.selectList("borrowme.mapper.locFind", proNum);
    } finally {
      DBManager.closeSqlSession(session);
    }

    return list;
  }

  public List<BorrowDto> borrowList(String memMail) {
	    // TODO Auto-generated method stub
	    SqlSession session = null;
	    List<BorrowDto> list = null;
	    try{
	      session = DBManager.getSqlSession();
	      list = session.selectList("borrowme.mapper.borrowList", memMail);
	    }finally{
	      DBManager.closeSqlSession(session);
	    }
	    
	    return list;
	  }

  @Override
  public boolean insertProductKidsort(ProductDto product) {
    // TODO Auto-generated method stub
    SqlSession session = null;
    boolean result = false;

    try {
      session = DBManager.getSqlSession();
      result = session.insert("borrowme.mapper.insertProductKidsort", product) > 0 ? true : false;
    } finally {
      DBManager.closeSqlSession(result, session);
    }

    return result;
  }

  @Override
  public boolean insertProductItSort(ProductDto product) {
    // TODO Auto-generated method stub
    SqlSession session = null;
    boolean result = false;

    try {
      session = DBManager.getSqlSession();
      result = session.insert("borrowme.mapper.insertProductItSort", product) > 0 ? true : false;
    } finally {
      DBManager.closeSqlSession(result, session);
    }

    return result;
  }

  @Override
  public boolean insertProductSposort(ProductDto product) {
    // TODO Auto-generated method stub
    SqlSession session = null;
    boolean result = false;

    try {
      session = DBManager.getSqlSession();
      result = session.insert("borrowme.mapper.insertProductSposort", product) > 0 ? true : false;
    } finally {
      DBManager.closeSqlSession(result, session);
    }

    return result;
  }

  @Override
  public boolean insertProductHobsort(ProductDto product) {
    // TODO Auto-generated method stub
    SqlSession session = null;
    boolean result = false;

    try {
      session = DBManager.getSqlSession();
      result = session.insert("borrowme.mapper.insertProductHobsort", product) > 0 ? true : false;
    } finally {
      DBManager.closeSqlSession(result, session);
    }

    return result;
  }

  @Override
  public String selectProductNum(String memMail) {
    // TODO Auto-generated method stub
    SqlSession session = null;
    String result = null;

    try {
      session = DBManager.getSqlSession();
      result = session.selectOne("borrowme.mapper.selectProductNum", memMail);
    } finally {
      DBManager.closeSqlSession(session);
    }
    return result;
  }

  @Override
  public boolean insertItemImg(ItemImgDto itemImg) {
    // TODO Auto-generated method stub
    SqlSession session = null;
    boolean result = false;

    try {
      session = DBManager.getSqlSession();
      result = session.insert("borrowme.mapper.insertItemImg", itemImg) > 0 ? true : false;
    } finally {
      DBManager.closeSqlSession(result, session);
    }

    return result;
  }

	@Override
	public List<ProductDto> categoryOneByMenu(String proSort) {
		// TODO Auto-generated method stub
		SqlSession session = null;
		List<ProductDto> list = null;
		
		try{
			 session = DBManager.getSqlSession();
		      list = session.selectList("borrowme.mapper.categoryOneByMenu", proSort);
		}finally{
			DBManager.closeSqlSession(session);
		}
		
		return list;
	}
	

	@Override
	public List<ProductDto> categoryByOption(String menu, String sortOption) {
		// TODO Auto-generated method stub
		SqlSession session = null;
		List<ProductDto> list = null;
		Map<String, String> map = new HashMap<String, String>();
		
		map.put("menu", menu);
		map.put("sortOption", sortOption);
		
		try{
			 session = DBManager.getSqlSession();
			 list = session.selectList("borrowme.mapper.categoryOneByOption", map);
			 if(sortOption!=null && sortOption.equals("전체")){
				 String proSort = menu;
				 list = session.selectList("borrowme.mapper.categoryOneByMenu", proSort);
			 }else{
				 list = session.selectList("borrowme.mapper.categoryOneByOption", map);
			 }
		}finally{
			DBManager.closeSqlSession(session);
		}
		
		return list;
	}

  @Override
  public List<ProductDto> selectProductMainList(int mainNum) {
    // TODO Auto-generated method stub
    SqlSession session = null;
    List<ProductDto> list = null;

    try {
      session = DBManager.getSqlSession();
      list = session.selectList("borrowme.mapper.selectProductMainList", mainNum);
    } finally {
      DBManager.closeSqlSession(session);
    }

    return list;
  }



	@Override
	public CartDto cartList(String choice) {
		SqlSession session = null;
		CartDto list = null;
		
		try{
			 session = DBManager.getSqlSession();
		      list = session.selectOne("borrowme.mapper.cartList", choice);
		}finally{
			DBManager.closeSqlSession(session);
		}
		
		return list;
	}


//	public List<ThumbNailDto> ThumbList(String proNum,String memMail) {
//	    // TODO Auto-generated method stub
//	    SqlSession session = null;
//	    List<BorrowDto> list = null;
//	    Map<String, String> map = new HashMap<String, String>();
//		map.put("proNum", proNum);
//		map.put("memMail", memMail);
//	    try{
//	      session = DBManager.getSqlSession();
//	      list = session.selectList("borrowme.mapper.proNum", map);
//	    }finally{
//	      DBManager.closeSqlSession(session);
//	    }
//	    
//	    return list;
//	  }

}
