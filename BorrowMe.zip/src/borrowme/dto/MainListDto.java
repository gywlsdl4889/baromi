package borrowme.dto;

public class MainListDto {
  private String proNum;
  private String proName;
  private String proCost;
  private String iteFile;
  
  public MainListDto(){
    super();
  }

  public String getProNum() {
    return proNum;
  }

  public void setProNum(String proNum) {
    this.proNum = proNum;
  }

  public String getProName() {
    return proName;
  }

  public void setProName(String proName) {
    this.proName = proName;
  }

  public String getProCost() {
    return proCost;
  }

  public void setProCost(String proCost) {
    this.proCost = proCost;
  }

  public String getIteFile() {
    return iteFile;
  }

  public void setIteFile(String iteFile) {
    this.iteFile = iteFile;
  }
  
  
}
