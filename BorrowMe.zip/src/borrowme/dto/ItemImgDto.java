package borrowme.dto;

public class ItemImgDto{
	private String proNum;
	private String IteIdx;
	private String iteFile;
	
	public ItemImgDto(){
		super();
	}

	public String getProNum() {
		return proNum;
	}

	public void setProNum(String proNum) {
		this.proNum = proNum;
	}

	public String getIteIdx() {
		return IteIdx;
	}

	public void setIteIdx(String iteIdx) {
		IteIdx = iteIdx;
	}

	public String getIteFile() {
		return iteFile;
	}

	public void setIteFile(String iteFile) {
		this.iteFile = iteFile;
	}
	
	

}