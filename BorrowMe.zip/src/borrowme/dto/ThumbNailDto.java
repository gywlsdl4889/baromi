package borrowme.dto;

public class ThumbNailDto {
	private String iteFile;
	private String proNum;
	private String iteIdx;
	
	public ThumbNailDto(){
		super();
	}
	
	public String getIteFile() {
		return iteFile;
	}
	public void setIteFile(String iteFile) {
		this.iteFile = iteFile;
	}
	public String getProNum() {
		return proNum;
	}
	public void setProNum(String proNum) {
		this.proNum = proNum;
	}
	public String getIteIdx() {
		return iteIdx;
	}
	public void setIteIdx(String iteIdx) {
		this.iteIdx = iteIdx;
	}
}
