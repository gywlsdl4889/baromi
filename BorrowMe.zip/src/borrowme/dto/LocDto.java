package borrowme.dto;

public class LocDto {
	private String proNum;
	private String offNum;
	private String offName;
	private String locArrival;
	private String memmail;
	
	public LocDto(){
		super();
	}
	
	public String getProNum() {
		return proNum;
	}
	public void setProNum(String proNum) {
		this.proNum = proNum;
	}
	public String getOffNum() {
		return offNum;
	}
	public void setOffNum(String offNum) {
		this.offNum = offNum;
	}
	public String getOffName() {
		return offName;
	}
	public void setOffName(String offName) {
		this.offName = offName;
	}
	public String getLocArrival() {
		return locArrival;
	}
	public void setLocArrival(String locArrival) {
		this.locArrival = locArrival;
	}

	public String getMemmail() {
		return memmail;
	}

	public void setMemmail(String memmail) {
		this.memmail = memmail;
	}
}
