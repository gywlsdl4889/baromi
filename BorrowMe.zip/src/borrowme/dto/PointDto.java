package borrowme.dto;

import java.util.Date;

public class PointDto {
  private String memMail;   // ȸ��e-mail
  private Date poiDate;     // �߻��Ͻ�
  private int poiPoint;     // ����Ʈ
  private String poiSort;   // ��뱸��
  
  public PointDto(){
    super();
  }

  public String getMemMail() {
    return memMail;
  }

  public void setMemMail(String memMail) {
    this.memMail = memMail;
  }

  public Date getPoiDate() {
    return poiDate;
  }

  public void setPoiDate(Date poiDate) {
    this.poiDate = poiDate;
  }

  public int getPoiPoint() {
    return poiPoint;
  }

  public void setPoiPoint(int poiPoint) {
    this.poiPoint = poiPoint;
  }

  public String getPoiSort() {
    return poiSort;
  }

  public void setPoiSort(String poiSort) {
    this.poiSort = poiSort;
  }
  
  
}
