package borrowme.dto;

import java.util.Date;

public class LendDto {
	private String proNum;
	private String proName;
	private String proDate;
	private String offName;
	private String proCost;
	private String proAvail;

	public LendDto() {
		super();
	}

	public String getProNum() {
		return proNum;
	}

	public void setProNum(String proNum) {
		this.proNum = proNum;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getProDate() {
		return proDate;
	}

	public void setProDate(String proDate) {
		this.proDate = proDate;
	}

	public String getOffName() {
		return offName;
	}

	public void setOffName(String offName) {
		this.offName = offName;
	}

	public String getProCost() {
		return proCost;
	}

	public void setProCost(String proCost) {
		this.proCost = proCost;
	}

	public String getProAvail() {
		return proAvail;
	}

	public void setProAvail(String proAvail) {
		this.proAvail = proAvail;
	}


	

}
