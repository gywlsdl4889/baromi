package borrowme.dto;

public class OfficeDto {
  private String offNum;  // ��������ȣ pk
  private String offName; // ��������
  private String offHp;   // ����������ó
  private String offAddr; // �������ּ�

  public OfficeDto(){
    super();
  }

public String getOffNum() {
	return offNum;
}

public void setOffNum(String offNum) {
	this.offNum = offNum;
}

public String getOffName() {
	return offName;
}

public void setOffName(String offName) {
	this.offName = offName;
}

public String getOffHp() {
	return offHp;
}

public void setOffHp(String offHp) {
	this.offHp = offHp;
}

public String getOffAddr() {
	return offAddr;
}

public void setOffAddr(String offAddr) {
	this.offAddr = offAddr;
}
  
}
