package borrowme.dto;

public class LocationDto{
	private String proNum;
	private String offNum;
	private String locArrival;
	private String locStateCode;
	

	public LocationDto(){
		super();
	}


	public String getProNum() {
		return proNum;
	}


	public void setProNum(String proNum) {
		this.proNum = proNum;
	}


	public String getOffNum() {
		return offNum;
	}


	public void setOffNum(String offNum) {
		this.offNum = offNum;
	}


	public String getLocArrival() {
		return locArrival;
	}


	public void setLocArrival(String locArrival) {
		this.locArrival = locArrival;
	}


	public String getLocStateCode() {
		return locStateCode;
	}


	public void setLocStateCode(String locStateCode) {
		this.locStateCode = locStateCode;
	}
	
	
	
}