package borrowme.dto;

import java.util.Date;

public class ProductDto {
	private String proNum; // ��ǰ��ȣ pk
	private String proName; // ��ǰ��
	private String proDetail; // ��ǰ�󼼳���
	private Date proDate; // ��ǰ����Ͻ�
	private String proSort; // ��ǰ����
	private int proCost; // �뿩����
	private String proAvail; // �뿩���ɿ���
	private int proCount; // ��ȸ��
	private int proRate; // ������
	private String memMail; // ȸ�� e-mail fk
	private String cloSort;
	private String kidSort;
	private String itSort;
	private String spoSort;
	private String hobSort;
	private String iteFile;
	
	public ProductDto() {
		super();
	}

	public String getProNum() {
		return proNum;
	}

	public void setProNum(String proNum) {
		this.proNum = proNum;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getProDetail() {
		return proDetail;
	}

	public void setProDetail(String proDetail) {
		this.proDetail = proDetail;
	}

	public Date getProDate() {
		return proDate;
	}

	public void setProDate(Date proDate) {
		this.proDate = proDate;
	}

	public String getProSort() {
		return proSort;
	}

	public void setProSort(String proSort) {
		this.proSort = proSort;
	}

	public int getProCost() {
		return proCost;
	}

	public void setProCost(int proCost) {
		this.proCost = proCost;
	}

	public String getProAvail() {
		return proAvail;
	}

	public void setProAvail(String proAvail) {
		this.proAvail = proAvail;
	}

	public int getProCount() {
		return proCount;
	}

	public void setProCount(int proCount) {
		this.proCount = proCount;
	}

	public int getProRate() {
		return proRate;
	}

	public void setProRate(int proRate) {
		this.proRate = proRate;
	}

	public String getMemMail() {
		return memMail;
	}

	public void setMemMail(String memMail) {
		this.memMail = memMail;
	}

	public String getCloSort() {
		return cloSort;
	}

	public void setCloSort(String cloSort) {
		this.cloSort = cloSort;
	}

	public String getKidSort() {
		return kidSort;
	}

	public void setKidSort(String kidSort) {
		this.kidSort = kidSort;
	}

	public String getItSort() {
		return itSort;
	}

	public void setItSort(String itSort) {
		this.itSort = itSort;
	}

	public String getSpoSort() {
		return spoSort;
	}

	public void setSpoSort(String spoSort) {
		this.spoSort = spoSort;
	}

	public String getHobSort() {
		return hobSort;
	}

	public void setHobSort(String hobSort) {
		this.hobSort = hobSort;
	}

	public String getIteFile() {
		return iteFile;
	}

	public void setIteFile(String iteFile) {
		this.iteFile = iteFile;
	}

}
