package borrowme.dto;

public class MemberDto {
  private String memMail;   // ȸ��e-mail pk
  private String memPw;     // ��й�ȣ
  private String memName;   // ȸ���̸�
  private String memAddr;   // ȸ���ּ�
  private String memHp;     // ȸ������ó
  private String memGen;    // ����
  private String memBirth;  // �������
  private int memPoint;     // ������Ʈ
  
  public MemberDto() {
    super();
  }
  
  public MemberDto(String memMail, String memPw, String memName, String memBirth, String memGen, String memHp, String memAddr){
    this.memMail = memMail;
    this.memPw = memPw;
    this.memName = memName;
    this.memBirth = memBirth;
    this.memGen = memGen;
    this.memHp = memHp;
    this.memAddr = memAddr;
  }
  
  public MemberDto(String memPw, String memHp, String memAddr) {
		this.memPw = memPw;
		this.memHp = memHp;
		this.memAddr = memAddr;
	}
  
  public String getMemMail() {
    return memMail;
  }
  
  public void setMemMail(String memMail) {
    this.memMail = memMail;
  }
  
  public String getMemPw() {
    return memPw;
  }
  
  public void setMemPw(String memPw) {
    this.memPw = memPw;
  }
  
  public String getMemName() {
    return memName;
  }
  public void setMemName(String memName) {
    this.memName = memName;
  }
  
  public String getMemAddr() {
    return memAddr;
  }
  
  public void setMemAddr(String memAddr) {
    this.memAddr = memAddr;
  }
  
  public String getMemHp() {
    return memHp;
  }
  public void setMemHp(String memHp) {
    this.memHp = memHp;
  }
  
  public String getMemGen() {
    return memGen;
  }
  
  public void setMemGen(String memGen) {
    this.memGen = memGen;
  }
  
  public String getMemBirth() {
    return memBirth;
  }
  
  public void setMemBirth(String memBirth) {
    this.memBirth = memBirth;
  }
  
  public int getMemPoint() {
    return memPoint;
  }
  
  public void setMemPoint(int memPoint) {
    this.memPoint = memPoint;
  }

}
