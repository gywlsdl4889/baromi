package borrowme.dto;

public class BorrowDto {
	private String proNum;
	private String proName;
	private String ordStart;
	private String ordEnd;
	private String memMail;
	private String iteFile;
	private String iteIdx;
	
	public String getProNum() {
		return proNum;
	}

	public void setProNum(String proNum) {
		this.proNum = proNum;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getOrdStart() {
		return ordStart;
	}

	public void setOrdStart(String ordStart) {
		this.ordStart = ordStart;
	}

	public String getOrdEnd() {
		return ordEnd;
	}

	public void setOrdEnd(String ordEnd) {
		this.ordEnd = ordEnd;
	}

	public String getMemMail() {
		return memMail;
	}

	public void setMemMail(String memMail) {
		this.memMail = memMail;
	}

	public BorrowDto(){
		super();
	}

	public String getIteFile() {
		return iteFile;
	}

	public void setIteFile(String iteFile) {
		this.iteFile = iteFile;
	}

	public String getIteIdx() {
		return iteIdx;
	}

	public void setIteIdx(String iteIdx) {
		this.iteIdx = iteIdx;
	}
}
