// ajax
function createXMLHttpRequest() {
	if (window.ActiveXObject) {
		xhr = new ActiveXObject("Microsoft.XMLHTTP");
	} else {
		xhr = new XMLHttpRequest();
	}
	return xhr;
}

// Email 체크
function checkId() {
	var memMail = document.registerForm.memMail.value;
	var idPattern = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/; // 이메일
	// 유효성
	// 체크
	if (memMail == "") {
		alert("이메일형식으로 입력해주세요.");
		document.registerForm.memMail.focus();
		return false;
	}
	if (idPattern.test(memMail) == false) {
		document.getElementById("idcheck").innerHTML = "이메일형식으로 입력해주세요.";
		document.registerForm.memMail.value = "";
		document.registerForm.memMail.focus();
		return false;
	}
	xhr = createXMLHttpRequest();
	xhr.onreadystatechange = checkIdShowResult;
	xhr.open("get", "member?cmd=checkMail&memMail=" + memMail, true);
	xhr.setRequestHeader('Content-Type',
			'application/x-www-form-urlencoded;charset=utf-8');
	xhr.send(null);
}
function checkIdShowResult() {
	if (xhr.readyState == 4) {
		if (xhr.status == 200) {
			var flag = xhr.responseText;
			// alert("flag"+flag);
			if (flag == "true") {
				document.getElementById("idcheck").innerHTML = "사용불가";
				document.registerForm.memMail.value = "";
				document.registerForm.memMail.focus();
			} else {
				document.getElementById("idcheck").innerHTML = "사용가능";
				document.registerForm.memPw.focus();
			}
		}
	}
}

function registerCheck() {
	// 이메일이 입력 되었는지 확인
	var idText = document.registerForm.id;
	if (id.value == "") {
		alert("이메일형식으로 입력해주세요.");
		idText.value = "";
		idText.focus();
		return false;
	}

	// email이 정규식에 포함되었는지 확인
	var idPattern = new RegExp(
			'/^[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*\.[a-zA-Z]{2,3}$/i'); // 이메일정규식(a-z
	// A-Z
	// 0-9
	// _)체크
	if (idPattern.test(idText.value)) {
		alert("이메일형식으로 입력해주세요.");
		idText.value = "";
		idText.focus();
		return false;
	}

}

// 비밀번호 체크
function checkPwd() {
	var memPw = document.registerForm.memPw.value;
	var memPw2 = document.registerForm.memPw2.value;
	var resultStr = '';
	if(memPw != '' && memPw2 != ''){

		if (memPw != memPw2) {
			resultStr = '<span id="result_false">동일한 비밀번호를 입력하세요.</span>'
			document.getElementById('pwdcheck').style.color = "red";
			document.getElementById('pwdcheck').innerHTML = resultStr;
			pwFlag = false;
		} else {
			resultStr = '<span id="result_true">비밀번호가 일치합니다.</span>'
			document.getElementById('pwdcheck').style.color = "blue";
			document.getElementById('pwdcheck').innerHTML = resultStr;
			pwFlag = true;
		}
	}
}

// 현재비밀번호 확인
function checkCurrentPw() {
	var memMail = document.userModifyForm.mail.value;
	var memPw = document.userModifyForm.memPw.value;

	xhr = createXMLHttpRequest();
	xhr.onreadystatechange = checkPwShowResult;
	xhr.open("get", "member?cmd=checkPw&memMail="+memMail+"&memPw=" + memPw, true);
	xhr.setRequestHeader('Content-Type',
			'application/x-www-form-urlencoded;charset=utf-8');
	xhr.send(null);
}
function checkPwShowResult() {
	if (xhr.readyState == 4) {
		if (xhr.status == 200) {
			var flag = xhr.responseText;
			 //alert("flag"+flag);
			if (flag == "true") {
				document.getElementById("pwcheck").innerHTML = "비번일치";
				document.userModifyForm.memPw2.focus();
			} else {
				document.getElementById("pwcheck").innerHTML = "비번불일치";
				
			}
		}
	}
}

// 업데이트 회원 체크
function UpdateMemCheck() {
	// 비밀번호가 입력 되었는지 확인
	var pwText = document.userModifyForm.memPw;
	if (pwText == null) {
		alert("현재비밀번호를 입력해주세요.");
		pwText.value = "";
		pwText.focus();
		return false;
	}
	
	var memPw2 = document.userModifyForm.memPw2.value;
	var memPw3 = document.userModifyForm.memPw3.value;
	var resultStr = '';
	if(memPw2 != '' && memPw3 != ''){

		if (memPw2 != memPw3) {
			resultStr = '<span id="result_false">동일한 비밀번호를 입력하세요.</span>'
			document.getElementById('pwdcheck').style.color = "red";
			document.getElementById('pwdcheck').innerHTML = resultStr;
			pwFlag = false;
		} else {
			resultStr = '<span id="result_true">비밀번호가 일치합니다.</span>'
			document.getElementById('pwdcheck').style.color = "blue";
			document.getElementById('pwdcheck').innerHTML = resultStr;
			pwFlag = true;
		}
	}


}

//주소 찾기 API 회원가입용
function execDaumPostcode() {
	new daum.Postcode({
		oncomplete : function(data) {
			// 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

			// 각 주소의 노출 규칙에 따라 주소를 조합한다.
			// 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
			var fullAddr = ''; // 최종 주소 변수
			var extraAddr = ''; // 조합형 주소 변수

			// 사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
			if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
				fullAddr = data.roadAddress;

			} else { // 사용자가 지번 주소를 선택했을 경우(J)
				fullAddr = data.jibunAddress;
			}

			// 사용자가 선택한 주소가 도로명 타입일때 조합한다.
			if (data.userSelectedType === 'R') {
				// 법정동명이 있을 경우 추가한다.
				if (data.bname !== '') {
					extraAddr += data.bname;
				}
				// 건물명이 있을 경우 추가한다.
				if (data.buildingName !== '') {
					extraAddr += (extraAddr !== '' ? ', ' + data.buildingName
							: data.buildingName);
				}
				// 조합형주소의 유무에 따라 양쪽에 괄호를 추가하여 최종 주소를 만든다.
				fullAddr += (extraAddr !== '' ? ' (' + extraAddr + ')' : '');
			}

			// 우편번호와 주소 정보를 해당 필드에 넣는다.
			// document.getElementById('postcode').value = data.zonecode; //5자리
			// 새우편번호 사용
			document.getElementById('memAddr').value = fullAddr;

			// 커서를 핸드폰 필드로 이동한다.
			document.getElementById('memHp').focus();
		}
	}).open();
}

//주소 찾기 API 회원수정용
function execDaumPostcode2() {
	new daum.Postcode({
		oncomplete : function(data) {
			// 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

			// 각 주소의 노출 규칙에 따라 주소를 조합한다.
			// 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
			var fullAddr = ''; // 최종 주소 변수
			var extraAddr = ''; // 조합형 주소 변수

			// 사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
			if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
				fullAddr = data.roadAddress;

			} else { // 사용자가 지번 주소를 선택했을 경우(J)
				fullAddr = data.jibunAddress;
			}

			// 사용자가 선택한 주소가 도로명 타입일때 조합한다.
			if (data.userSelectedType === 'R') {
				// 법정동명이 있을 경우 추가한다.
				if (data.bname !== '') {
					extraAddr += data.bname;
				}
				// 건물명이 있을 경우 추가한다.
				if (data.buildingName !== '') {
					extraAddr += (extraAddr !== '' ? ', ' + data.buildingName
							: data.buildingName);
				}
				// 조합형주소의 유무에 따라 양쪽에 괄호를 추가하여 최종 주소를 만든다.
				fullAddr += (extraAddr !== '' ? ' (' + extraAddr + ')' : '');
			}

			// 우편번호와 주소 정보를 해당 필드에 넣는다.
			// document.getElementById('postcode').value = data.zonecode; //5자리
			// 새우편번호 사용
			document.getElementById('updateAddr').value = fullAddr;

			// 커서를 핸드폰 필드로 이동한다.
			//document.getElementById('memAddr').focus();
		}
	}).open();
}

//휴대폰번호 체크 회원가입용
function checkHp() {
	var memHp = document.registerForm.memHp.value;
	var hpPattern = /^((01[1|6|7|8|9])[1-9]+[0-9]{6,7})|(010[1-9][0-9]{7})$/; // 휴대폰 정규식
	// 유효성
	// 체크
	if (!hpPattern.test(memHp)) {
		document.getElementById('hpcheck').style.color = "red";
		document.getElementById("hpcheck").innerHTML = "적합한 폰번호형식으로 입력해주세요.";
		document.registerForm.memHp.focus();
	}else{
		document.getElementById('hpcheck').style.color = "blue";
		document.getElementById("hpcheck").innerHTML = "적합한 폰번호입니다.";
		document.registerForm.memAddr.focus();
	}
}

//휴대폰번호 체크 회원수정용
function checkHp2() {
	var memHp2 = document.userModifyForm.memHp2.value;
	var hpPattern = /^((01[1|6|7|8|9])[1-9]+[0-9]{6,7})|(010[1-9][0-9]{7})$/; // 휴대폰 정규식
	// 유효성
	// 체크
	if (!hpPattern.test(memHp2)) {
		document.getElementById('hpcheck2').style.color = "red";
		document.getElementById("hpcheck2").innerHTML = "적합한 폰번호형식으로 입력해주세요.";
		document.userModifyForm.memHp.focus();
	}else{
		document.getElementById('hpcheck2').style.color = "blue";
		document.getElementById("hpcheck2").innerHTML = "적합한 폰번호입니다.";
		document.userModifyForm.memAddr.focus();
	}
}

/*//생년월일 체크
function checkBirth() {
	var memBirth = document.registerForm.memBirth.value;
	//var birthPattern = /^(19|20)\d{2}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[0-1])$/; // 생년월일 정규식
	var nowDate = new Date();
	var nYear = nowDate.getFullYear();
	var nMonth = (nowDate.getMonth()+1);
	var nDate = nowDate.getDate();
	
	var birthYear = memBirth.substring(0,4);
	var birthMonth = memBirth.substring(5,7);
	var birthDate = memBirth.substring(8,10);
	
	console.log(parseInt(nYear));
	console.log(parseInt(birthYear));
	if (parseInt(nYear)<parseInt(birthYear)) {
		document.getElementById('birthcheck').style.color = "red";
		document.getElementById("birthcheck").innerHTML = "적합한 연도 형식으로 입력해주세요.";
	}
	if(parseInt(nYear)==parseInt(birthYear) && parseInt(nMonth)<parseInt(birthMonth)){
		document.getElementById('birthcheck').style.color = "red";
		document.getElementById("birthcheck").innerHTML = "적합한 월 형식으로 입력해주세요.";
	}
//	if(parseInt(nYear)==parseInt(birthYear) && parseInt(nMonth)==parseInt(birthMonth) && parseInt(nDate)<parseInt(birthDate)){
//		document.getElementById('birthcheck').style.color = "red";
//		document.getElementById("birthcheck").innerHTML = "적합한 일 형식으로 입력해주세요.";
//	}
	else{
		document.getElementById('birthcheck').style.color = "blue";
		document.getElementById("birthcheck").innerHTML = "적합한 연도 형식입니다.";
	}
}*/
