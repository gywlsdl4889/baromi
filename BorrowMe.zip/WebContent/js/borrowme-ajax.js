$(function() {
  $.ajax({
    url : "product?cmd=productMainList",
    type : "post",
    data : {},
    contentType: "application/x-www-form-urlencoded; charset=UTF-8",  
    datatype : "json",
    error : function(req) {
      alert("loadProductMainList Error : " + req.status);
    },
    success : function(replyResult) {
      var str = "";
      jsonData = $.parseJSON(replyResult);
      if (jsonData.length == 0) {

      } else {
        var col = 4;
        var row = jsonData.length/4;
        var count = 0;
        row = row==0 ? 1 : row;
        
        for(var i=0; i<row; i++) {
          console.log("i : " + i);
          str += "<div class='section group'>";
          for(var j=0; j<col; j++) {
            str += "<div class='grid_1_of_4 images_1_of_4'>";
            str += "<a href='product?cmd=preview&proNum="+ jsonData[count].proNum +"'><img src='upload/"+ jsonData[count].iteFile +"' /></a>";
            str += "<div style= text-align:left><h2>"+ jsonData[count].proName +"</h2></div>";
            str += "<div class='price-details'><div class='price-number'><p>";
            str += "<span class='rupees'>"+ jsonData[count].proCost +"</span>";
            str += "</p></div><div class='clear'></div></div></div>";
            count++;
            if(count==jsonData.length)
              break; 
          }
          str += "</div>";
        } 
      }

      $("#mainList").html(str);
      $("#mainList").show();
    }
  });
});