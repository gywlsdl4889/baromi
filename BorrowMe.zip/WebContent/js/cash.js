function cashUpdate(){
  var _this = document.getElementsByName("cash");
  var currentCash = document.getElementById("currentCash"); 
  var nextCash = document.getElementById("nextCash");
  var inputValue = document.getElementById("inputValue");
  var result = 0;
  var idx = 0;
  
  for(var i=0; i<_this.length; i++){
    if(_this[i].checked == true){
      idx = i;
      break;
    }
  }
  if(idx==_this.length-1){
    _this[idx].value = inputValue.value;
  } else {
    _this[_this.length-1].value = '';
    inputValue.value = '';
  }
  
  result = Number(currentCash.value) + Number(_this[idx].value);
  nextCash.innerHTML = Number(result).toLocaleString('en') +"원";
}

function cashKeyUpdate() {
  var _this = document.getElementsByName("cash");
  _this[_this.length-1].checked = "checked";
  cashUpdate();
}

