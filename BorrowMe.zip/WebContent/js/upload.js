
function Category1(value, code) {
	this.value = value;
	this.code = code;
	this.length = 0;
}
function addCategory1(category, value, code) {
	category[category.length] = new Category1(value, code);
	category.length++;
}
function Category(value) {
	this.value = value;
	this.length = 0;
}
function addCategory(category, value) {
	category[category.length] = new Category(value);
	category.length++;
}

 local = new Category1();
addCategory1(local, "가평","0001");
addCategory1(local, "고양","0002");
addCategory1(local, "과천","0003");
addCategory1(local, "광명","0004");
addCategory1(local, "광주","0005");
addCategory1(local, "구리","0006");
addCategory1(local, "군포","0007");
addCategory1(local, "김포","0008");
addCategory1(local, "남양주","0009");
addCategory1(local, "동두천","0010");
addCategory1(local, "부천","0011");
addCategory1(local, "성남","0012");
addCategory1(local, "수원","0013");
addCategory1(local, "시흥","0014");
addCategory1(local, "안산","0015");
addCategory1(local, "안성","0016");
addCategory1(local, "안양","0017");
addCategory1(local, "양주","0018");
addCategory1(local, "양평","0019");
addCategory1(local, "여주","0020");
addCategory1(local, "연천","0021");
addCategory1(local, "오산","0022");
addCategory1(local, "용인","0023");
addCategory1(local, "의왕","0024");
addCategory1(local, "의정부","0025");
addCategory1(local, "이천","0026");
addCategory1(local, "파주","0027");
addCategory1(local, "평택","0028");
addCategory1(local, "포천","0029");
addCategory1(local, "하남","0030");
addCategory1(local, "화성","0031");

 category = new Category();
addCategory(category, "의류");
addCategory(category[0], "셔츠");
addCategory(category[0], "티셔츠");
addCategory(category[0], "맨투맨");
addCategory(category[0], "니트/가디건");
addCategory(category[0], "원피스");
addCategory(category[0], "아우터");
addCategory(category[0], "원피스");
addCategory(category[0], "팬츠");
addCategory(category[0], "치마");
addCategory(category[0], "악세사리");

addCategory(category, "아동제품");
addCategory(category[1], "유모차");
addCategory(category[1], "장난감");
addCategory(category[1], "보드게임");
addCategory(category[1], "출산준비용품");
addCategory(category[1], "유아용가구");
addCategory(category, "전자기기");
addCategory(category[2], "노트북");
addCategory(category[2], "디지털카메라");
addCategory(category[2], "스마트폰");
addCategory(category[2], "태블릿PC");
addCategory(category[2], "기타");
addCategory(category, "스포츠");
addCategory(category[3], "이동수단");
addCategory(category[3], "헬스기기");
addCategory(category[3], "스키/보드");
addCategory(category, "취미");
addCategory(category[4], "낚시");
addCategory(category[4], "악기");
addCategory(category[4], "캠핑");


function initForm(form) {
	form.proSort.length = category.length;
	for (i = 0; i < category.length; i++)
		form.proSort[i].text = category[i].value;
	form.proSort.selectedIndex = 0;
	form.detailSort.selectedIndex = 0;
	change_subject(form);
	setLocation();
}

function setLocation() {
	form.local.length = local.length;
	for (i = 0; i < local.length; i++){
		form.local[i].text = local[i].value;
		form.local[i].value = local[i].code;
	}
		
	form.local.selectedIndex = 0;
}

function change_subject(form) {
	// alert(form)
	var i = form.proSort.selectedIndex;
	form.detailSort.length = category[i].length;
	for (j = 0; j < form.detailSort.length; j++)
		form.detailSort[j].text = category[i][j].value;
	form.detailSort.selectedIndex = 0;
}




var count = 1;
var addCount;
// 행추가
function addInputBox() {
	for (var i = 1; i <= count; i++) {
		if (!document.getElementsByName("img" + i)[0]) {
			addCount = i;
			break;
		} else
			addCount = count;
	}
	if (count < 6) {
		var addStr = "<tr><td width=40><input type=checkbox name=checkList value="
				+ addCount
				+ " size=40 ></td><td width=140><input type=file name=img"
				+ addCount + " size=40></td></tr>";
		var table = document.getElementById("dynamic_table");
		var newRow = table.insertRow();
		var newCell = newRow.insertCell();
		newCell.innerHTML = addStr;
		count++;
	}
}

// 행삭제
function subtractInputBox() {
	var table = document.getElementById("dynamic_table");
	// var max = document.gForm.checkList.length;
	// alert(max);
	var rows = dynamic_table.rows.length;
	var chk = 0;
	if (rows > 1) {
		for (var i = 0; i < document.gForm.checkList.length; i++) {
			if (document.gForm.checkList[i].checked == true) {
				table.deleteRow(i);
				i--;
				count--;
				chk++;
			}
		}
		if (chk <= 0) {
			// alert("삭제할 행을 체크해 주세요.");
		}
	} else {
		// alert("더이상 삭제할 수 없습니다.");
	}
}

function submitbutton() {
	var gform = document.gForm;
	gform.count.value = eval(count);
	// alert(count);
	gForm.submit();
	return;
}

// 숫자만 입력받게하는거
function numbersonly(e, decimal, obj, num) {
	var key;
	var keychar;

	if (window.event) {
		key = window.event.keyCode;
	} else if (e) {
		key = e.which;
	} else {
		return true;
	}

	keychar = String.fromCharCode(key);

	if ((key == null) || (key == 0) || (key == 8) || (key == 9) || (key == 13)
			|| (key == 27)) {
		return true;
	} else if (obj.value.length >= num) { // 숫자제한부분
		return false;
	} else if ((("0123456789").indexOf(keychar) > -1)) {
		return true;
	} else if (decimal && (keychar == ".")) {
		return true;
	} else {
		return false;
	}
}

